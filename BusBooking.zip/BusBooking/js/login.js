function getEle(element) {
    return document.getElementById(element);
}

function KiemTraRong1() {
    var userName = getEle('userName').value;
    var pass = getEle('password').value;
    var thongbao = getEle('tb-submit');
    if (userName == "" || pass == "") {
        thongbao.innerHTML = "(*) Please fill your information";
        thongbao.style.display = "block";
        return false;
    } else {
        thongbao.style.display = "none";
        return true;
    }
}

// function KiemTraUsername(idTag) {
//     var inputTag = getEle(idTag);
//     var thongbao = getEle('tb-email');
//     var email = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" +
//         "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
//     if (inputTag.value.match(email)) {
//         thongbao.style.display = 'none';
//         return true;
//     } else {
//         thongbao.style.display = 'block';
//         thongbao.innerHTML = "(*) Email chưa hợp lệ";
//         return false;
//     }
// }


function Login() {
    return KiemTraRong1();
}