// function validate() {
// 	var firstName, lastName, email, user, pass, phone, expression, alertText;
// 	firstName = document.getElementById("firstName").value;
// 	lastName = document.getElementById("lastName").value;
// 	email = document.getElementById("email").value;
// 	user = document.getElementById("user").value;
// 	pass = document.getElementById("pass").value;
// 	phone = document.getElementById("phone").value;
// 	expression = /\w+@\w+\.+[a-z]/;
// 	//expression2 = /\w+@\w+\.+[a-z]+\.+[a-z]/;
// 	/*alertText = document.getElementById("alert-text").value;*/


// 	if(firstName === "" || lastName === "" || email === "" || user === "" || pass === "" || phone === ""){
// 		/*alertText.innerHTML = "All fields are required";*/
// 		alert("All fields are required");
// 		return false;
// 	}
// 	else if (firstName.length>30){
// 		alert("First Name is too long");
// 		return false;
// 	}
// 	else if (lastName.length>80){
// 		alert("Last Name is too long");
// 		return false;
// 	}
// 	else if (email.length>100){
// 		alert("Email is too long");
// 		return false;
// 	}
// 	else if(!expression.test(email)){
// 		alert("You didn't enter a valid email format");
// 		return false;
// 	}
// 	else if (user.length>20 || user.length<3 || pass.length>20 || pass.length<3){
// 		alert("User and Pass must be between 3 and 20 characters");
// 		return false;
// 	}
// 	else if (phone.length>20 || phone.length<10){
// 		alert("Phone Number must be between 10 and 20 digits");
// 		return false;
// 	}
// 	else if (isNaN(phone)){
// 		alert("Enter a valid Phone Number");
// 		return false;
// 	}
// }
function getEle(element) {
    return document.getElementById(element);
}


function KiemTraRong() {
    var userName = getEle('userName').value;
    var firstName = getEle('firstName').value;
    var lastName = getEle('lastName').value;
    var email = getEle('email').value;
    var password = getEle('password').value;
    var repassword = getEle('repassword').value;
    var govermentID = getEle('govermentID').value;
    var phoneNumber = getEle('phoneNumber').value;
    var thongbao = getEle('tb-submit1');
    if (userName == "" ||firstName == "" ||lastName == "" || email == "" || password == "" || repassword == "" || govermentID == "" || phoneNumber == "") {
        thongbao.innerHTML = "(*) Please fill full information";
        thongbao.style.display = "block";

        return false;
    } else {
        thongbao.style.display = "none";
        return true;
    }
}


function KiemTraMinMax(idTag1, TB1, content1, min, max) {
    var inputTag = getEle(idTag1).value;
    var thongbao = getEle(TB1);
    if (inputTag.length < min || inputTag.length > max) {
        thongbao.innerHTML = "(*) " + content1 + " must be from " + min + " to " + max + " characters";
        thongbao.style.display = "block";
        return false;
    } else {
        thongbao.style.display = "none";
        return true;
    }
}

function KiemTraEmail() {
    var inputTag = getEle('email');
    var thongbao = getEle('tb-email');
    var email = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" +
    "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    if (inputTag.value.match(email)) {
        thongbao.style.display = 'none';
        return true;
    } else {
        thongbao.style.display = 'block';
        thongbao.innerHTML = "(*) This Email is invalid";
        return false;
    }
}

function KiemTraRepass() {
    var pass = getEle('password');
    var repass = getEle('repassword');
    var thongbao = getEle('tb-repassword');
    if (pass.value != repass.value) {
        thongbao.style.display = 'block';
        thongbao.innerHTML = "(*)Your repassword is invalid";
        return false;
    } else {
        thongbao.style.display = 'none';
        return true;
    }

}
// function KiemTraCMND(cmnd){
//     var cmnd = getEle('cmnd');
//     var thongbao = getEle('tb-cmnd');
//     if(cmnd.length > 10){
//         thongbao.style.display = 'block';
//         thongbao.innerHTML = "(*) CMND phải ít hơn 10 kí tự";
//         return false;
//     } else if(cmnd.length < 10){
//         thongbao.style.display = 'block';
//         thongbao.innerHTML = "(*) CMND phải ít hơn 10 kí tự";
//         return false;
//     }
// }

function Register() {
    return KiemTraRong() &&
        KiemTraMinMax('userName', 'tb-userName', "Username", 3, 50) &&
        KiemTraMinMax('email', 'tb-email', "Email", 5, 50) &&
        KiemTraMinMax('firstName', 'tb-firstName', "firstName", 3, 50) &&
        KiemTraMinMax('lastName', 'tb-lastName', "lastName", 2, 50) &&
        KiemTraMinMax('password', 'tb-password', "Password", 8, 50) &&
        KiemTraMinMax('govermentID', 'tb-govermentID', "goverment ID", 9, 9) &&
        // KiemTraMinMax('quanhuyen', 'tb-quanhuyen', "Số Kí Tự Quá Ngắn", 4, 20) &&
        // KiemTraMinMax('city', 'tb-city', "Số Kí Tự Quá Ngắn", 4, 20) &&
        // KiemTraMinMax('diachi', 'tb-diachi', "Số Kí Tự Quá Ngắn", 4, 20) &&
        KiemTraEmail() &&
        KiemTraRepass();
}